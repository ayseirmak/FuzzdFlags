#include "lib/strnlen.c"
