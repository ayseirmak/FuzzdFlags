#define FLOAT float
#include "fp-cmp-8.c"
