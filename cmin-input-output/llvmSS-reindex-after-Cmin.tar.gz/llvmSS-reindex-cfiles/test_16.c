#include "lib/strncat.c"
