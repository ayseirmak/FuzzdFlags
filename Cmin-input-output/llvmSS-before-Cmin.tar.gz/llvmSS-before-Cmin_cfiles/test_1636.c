/* PR middle-end/71626 */
/* { dg-additional-options "-fpic" { target fpic } } */

#include "pr71626-1.c"
