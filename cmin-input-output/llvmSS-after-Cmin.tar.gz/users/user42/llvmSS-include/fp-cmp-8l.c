#define FLOAT long double
#include "fp-cmp-8.c"
