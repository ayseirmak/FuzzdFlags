#define FLOAT long double
#include "fp-cmp-4.c"
