#include "lib/memchr.c"
