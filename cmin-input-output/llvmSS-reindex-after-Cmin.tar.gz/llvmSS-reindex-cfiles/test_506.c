char a, h;
int b, d, e, g, j, k;
volatile int c;
short i;

int
main ()
{
  int m;

  m = i ^= 1;
  for (b = 0; b < 1; b++)
    {
      char o = m;
      g = k;
      j = j || c;
      if (a != o)
	for (; d < 1; d++)
	  ;
      else
	{
	  char *p = &h;
	  *p = 1;
	  for (; e; e++)
	    ;
	}
    }

  if (h != 0)
    __builtin_abort();

  return 0;
}
