#include <stdio.h>
int main(void) {
  long double x = 1.0;
  printf("%Lf %Lf\n", x, x);
  return 0;
}
