#include "lib/strncmp.c"
