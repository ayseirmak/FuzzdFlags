main()
{
  char blah[33] = "01234567890123456789";
  exit (0);
}
