/* { dg-require-effective-target int32plus } */

#define FIELDS1 long long l;
#include "20040629-1.c"
