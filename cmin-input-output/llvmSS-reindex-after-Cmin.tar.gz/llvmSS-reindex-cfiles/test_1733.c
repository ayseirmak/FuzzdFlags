#include "lib/memcmp.c"
