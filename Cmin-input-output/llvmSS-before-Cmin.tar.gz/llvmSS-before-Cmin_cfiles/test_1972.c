int main() {
  return 18;
}

