#define FLOAT float
#include "fp-cmp-4.c"
