long a = 1;

foo ()
{
  switch (a % 2 % 2 % 2 % 2 % 2 % 2 % 2 % 2)
    {
    case 0:
      return 0;
    case 1:
      return 1;
    default:
      return -1;
    }
}

main ()
{
  if (foo () != 1)
    abort ();
  exit (0);
}
